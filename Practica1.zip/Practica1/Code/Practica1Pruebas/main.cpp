#include <iostream>

#include <coladobleaviones.h>
#include <colasimplepasajeros.h>
#include <listadoblecirlucur.h>
#include <listadobleordenada.h>
#include <listasimple.h>

using namespace std;

int main()
{
    srand(time(NULL));




    return 0;
}
